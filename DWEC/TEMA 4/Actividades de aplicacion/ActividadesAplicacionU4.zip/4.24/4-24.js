function tablaMultiplicar(n){
    for(let i = 1; i <= 10; i++){
        document.write(`${i} x ${n} = ${i*n}<br>`);
    }
}

tablaMultiplicar(7);