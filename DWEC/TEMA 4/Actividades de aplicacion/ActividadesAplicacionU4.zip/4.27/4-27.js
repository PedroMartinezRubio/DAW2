(function (){
    document.write("Comenzando...<br>");
    setTimeout(function (){
        document.write("Finalizado");
    }, 3000);
})();