let colores = Array(5);

colores["Naranja"] = "#F39C12";
colores["Lima"] = "#C0F312";
colores["Turquesa"] = "#12F3E5";
colores["Rosa"] = "#F312AF";
colores["Rojo"] = "#F31212";

console.table(colores);