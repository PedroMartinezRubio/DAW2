let datos = new Map();

datos.set(61232189, "Pedro");
datos.set(698521478, "Sergio");
datos.set(685632145, "Pedro Miras");
datos.set(62542333, "Marta");
datos.set(635479821, "Adrian");
datos.set(645689741, "Maria");
datos.set(65896321, "Miriam");
datos.set(678965321, "Ana");
datos.set(663214589, "Juan");
datos.set(654789321, "Alicia");

for (let [numero, nombre] of datos) {
    console.log("El numero: "+numero+". Pertenece a la persona: "+nombre);
}
console.log("--------------------------------------");
console.log("Cambio el nombre de la tercera persona");
console.log("--------------------------------------");

datos.set(685632145, "Antonietta");

for (let [numero, nombre] of datos) {
    console.log("El numero: "+numero+". Pertenece a la persona: "+nombre);
}