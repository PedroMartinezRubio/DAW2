let elementos = [true, false, true, true, false, false, true, false, false, true];
let contador = 0;

while(contador < elementos.length){
    let indice = elementos.indexOf(true, contador);
    if(indice !== -1){
        console.log(indice);
    }
    contador++;
}