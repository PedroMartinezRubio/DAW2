let dni = Number(prompt("Introduce tu numero del DNI"));

let op = dni % 23;

switch(op){
    case 0:
        console.log("Tu letra es: T");
        console.log("Tu DNI completo es: "+dni+"T");
        break;
    case 1:
        console.log("Tu letra es: R");
        console.log("Tu DNI completo es: "+dni+"R");
        break;
    case 2:
        console.log("Tu letra es: W");
        console.log("Tu DNI completo es: "+dni+"W");
        break;
    case 3:
        console.log("Tu letra es: A");
        console.log("Tu DNI completo es: "+dni+"A");
        break;
    case 4:
        console.log("Tu letra es: G");
        console.log("Tu DNI completo es: "+dni+"G");
        break;
    case 5:
        console.log("Tu letra es: M");
        console.log("Tu DNI completo es: "+dni+"M");
        break;
    case 6:
        console.log("Tu letra es: Y");
        console.log("Tu DNI completo es: "+dni+"Y");
        break;
    case 7:
        console.log("Tu letra es: F");
        console.log("Tu DNI completo es: "+dni+"F");
        break;
    case 8:
        console.log("Tu letra es: P");
        console.log("Tu DNI completo es: "+dni+"P");
        break;
    case 9:
        console.log("Tu letra es: D");
        console.log("Tu DNI completo es: "+dni+"D");
        break;
    case 10:
        console.log("Tu letra es: X");
        console.log("Tu DNI completo es: "+dni+"X");
        break;
    case 11:
        console.log("Tu letra es: B");
        console.log("Tu DNI completo es: "+dni+"B");
        break;
    case 12:
        console.log("Tu letra es: N");
        console.log("Tu DNI completo es: "+dni+"N");
        break;
    case 13:
        console.log("Tu letra es: J");
        console.log("Tu DNI completo es: "+dni+"J");
        break;
    case 14:
        console.log("Tu letra es: Z");
        console.log("Tu DNI completo es: "+dni+"Z");
        break;
    case 15:
        console.log("Tu letra es: S");
        console.log("Tu DNI completo es: "+dni+"S");
        break;
    case 16:
        console.log("Tu letra es: Q");
        console.log("Tu DNI completo es: "+dni+"Q");
        break;
    case 17:
        console.log("Tu letra es: V");
        console.log("Tu DNI completo es: "+dni+"V");
        break;
    case 18:
        console.log("Tu letra es: H");
        console.log("Tu DNI completo es: "+dni+"H");
        break;
    case 19:
        console.log("Tu letra es: L");
        console.log("Tu DNI completo es: "+dni+"L");
        break;
    case 20:
        console.log("Tu letra es: C");
        console.log("Tu DNI completo es: "+dni+"C");
        break;
    case 21:
        console.log("Tu letra es: K");
        console.log("Tu DNI completo es: "+dni+"K");
        break;
    case 22:
        console.log("tu letra es: E");
        console.log("Tu DNI completo es: "+dni+"E");
        break;
    default:
        console.log("Ha introducido un DNI no valido.");
        break;
}