<?php 
        setcookie("nombre", false);
        setcookie("colorBack", time()-1);
        header("Location:index.php");
    
?>