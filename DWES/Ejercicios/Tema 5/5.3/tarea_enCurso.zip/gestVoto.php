<?php
    session_start();
    include 'conexion.php';

    $alumnoLog = $_SESSION['alumnoLog'];

    

    try{

        if(!empty($_POST['alumno'])){

            $alumno = $_POST['alumno'];
            $opcion = $_POST['volver'] ?? $_POST['votar'];

            if($opcion == "Volver"){
                header("Location: index.php");
                exit();
            }elseif($opcion == "Votar"){
                if($alumno == $alumnoLog){
                    throw new Exception("El alumno no puede votarse a si mismo.");
                }else{
                    
                }
            }
        }else{
            throw new Exception("Debe de introducir el alumno al que quiere votar.");
        }

    }catch(Exception $e){
        $_SESSION['error_message'] = $e->getMessage();
        header("Location: alumno.php");
        exit();
    }

?>