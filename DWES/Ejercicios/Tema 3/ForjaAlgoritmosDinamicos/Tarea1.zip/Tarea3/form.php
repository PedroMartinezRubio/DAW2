<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>El Archivo Maestro del Gremio</h1>
    <form action="<?php htmlspecialchars($_SERVER['PHP_SELF'])?>" method="post">
        <label>Nombre item:</label>
        <input type="text" name="nombre">
        <br>
        <select name="rareza">
            <option value="1">Comun</option>
            <option value="2">Raro</option>
            <option value="3">Epico</option>
        </select>
    </form>
    <?php 
        if($_POST){
            include 'funciones.php';
            $nombre = $_POST['nombre'];
            $rareza = $_POST['rareza'];
            $inventario = [
                0 => ['nombre' => 'pocion', 'cantidad' => 3, 'rareza' => 'comun'],
                1 => ['nombre' => 'pechera', 'cantidad' => 1, 'rareza' => 'raro'],
                2 => ['nombre' => 'baston', 'cantidad' => 1, 'rareza' => 'epico']
            ];
            $inventario_filtrado = [];
            try{
                if(empty($nombre)){
                    throw new Exception("El campo del nombre no puede estar vacio.");
                }elseif(is_numeric($nombre)){
                    throw new Exception("El valor introducido en el campo nombre no es valido.");
                }else{
                     agregarItem($inventario, $nombre, $rareza);
                     
                     foreach($inventario as $id){
                        $valor = obtenerRarezaValor($rareza);
                        if($valor >= $inventario[$id]['rareza']){
                            $inventario_filtrado[$id] = $inventario[$id];
                        }
                     }

                     echo "<table border=1px solid black>";
                }


            }catch(Exception $e){
                echo "Ha ocurrido un error: " . $e->getMessage() . " Espere unos segundos";
                header("refresh: 4 form.php");
            }            
        }
    ?>
</body>
</html>