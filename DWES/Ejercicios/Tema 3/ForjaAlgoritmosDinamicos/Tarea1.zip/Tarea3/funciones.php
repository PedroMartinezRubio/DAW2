<?php 
    function agregarItem(&$inventario, $nombre, $rareza = 'comun', $cantidad = 1){
        $id = count($inventario);
        $nuevoItem = [
            'nombre' => $nombre,
            'cantidad' => $cantidad,
            'rareza' => $rareza
        ];

        $inventario[$id] = $nuevoItem;
    }

    function obtenerRarezaValor($rareza){
        $valor = 0;
        if($rareza = "comun"){
            $valor = 1;
        }elseif($rareza = "raro"){
            $valor = 2;
        }else{
            $valor = 3;
        }
        return $valor;
    }
?>