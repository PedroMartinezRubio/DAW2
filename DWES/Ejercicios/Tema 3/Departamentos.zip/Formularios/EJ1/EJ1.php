<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>INDICE DE MASA CORPORAL</h1>
    <form action="result.php">
        <p>Escriba su peso y altura para calcular su IMC</p>
        <label for="peso">Peso: <input type="text" name="peso"></label>
        <br>
        <label for="altura">Altura: <input type="text" name="altura"></label>
        <br>
        <input type="submit" value="Calcular">
    </form>
</body>
</html>