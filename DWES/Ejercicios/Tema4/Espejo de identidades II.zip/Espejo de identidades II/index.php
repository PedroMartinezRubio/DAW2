<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>INSTITUTO</h1>
    <form action="" method="post">
        <label>Usuario:</label>
        <input type="text" name="usuario">
        <br>
        <label>Contraseña:</label>
        <input type="password" name="pw">
        <br>
        <label>Rol:</label>
        <select name="rol">
            <option value="">Profesor</option>
            <option value="">Delegado</option>
            <option value="">Estudiante</option>
        </select>
    </form>
</body>
</html>