<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        echo "<h1>Comparando variables en PHP</h1>"; 
        $fecha = date("y-m-d H:i:s");
        echo "<h2>Fecha actual: $fecha</h2>";
    ?>
</body>
</html>