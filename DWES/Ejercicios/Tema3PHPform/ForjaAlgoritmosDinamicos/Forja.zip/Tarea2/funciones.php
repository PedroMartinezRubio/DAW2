<?php 
    function dobleVerificacion($codigo){
        return $codigo * 2;
    }
?>