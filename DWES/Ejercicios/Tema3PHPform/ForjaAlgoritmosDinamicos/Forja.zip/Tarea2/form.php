<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>El Reloj del Cronometrador</h1>
    <form action="<?php htmlspecialchars($_SERVER['PHP_SELF'])?>" method="post">
        <label>Codigo mision:</label>
        <input type="text" name="codigo_mision[]">
        <br>
        <label>Codigo mision:</label>
        <input type="text" name="codigo_mision[]">
        <br>
        <label>Codigo mision:</label>
        <input type="text" name="codigo_mision[]">
        <br>
        <input type="submit" value="pito">
    </form>
    <?php 
        if($_POST){
            include 'funciones.php';
            $codigos = $_POST['codigo_mision[]'];

            try{
                 if(empty($codigos)){
                    
                 }
            }catch(Exception $e){
                echo "Ha ocurrido un error: " . $e->getMessage() . ". Por favor, espere unos segundos";
                header("refresh: 3 form.php");
            }
        }
    ?>
</body>
</html>