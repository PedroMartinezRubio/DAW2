<?php 
    function calcular($v1, $v2){
        $v1 *= 12;
        $v2 += $v1;
        $v2 *= 2.54;

        return $v2;
    }
?>