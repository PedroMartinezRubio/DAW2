<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Convierte segundos a minutos</h1>
    <p>Escribe una cantidad de segundos y la convertira en minutos y segundos.</p>
    <form action="process.php" method="post">
        <label for="segundos">Segundos: </label>
        <input type="text" name="seg" id="seg">
        <br>
        <input type="submit" value="Convertir">
    </form>
</body>
</html>