<?php 
    function calcularSueldo($nombre, $apellido, $edad, $salario){
        if($edad < 1000){
            if($edad < 30){
                $salario = 1100;
            }elsei($edad <= 30 && $edad < 45){
                $aumento = $salario * 0.3;
                $salario += $aumento;
            }else{
                $aumento = $salario *0.15;
                $salario += $aumento;
            }
        }

        if($salario >= 1000 && $salario < 2000){
            if($edad >= 45){
                $aumento = $salario *0.03;
                $salario += $aumento;
            }else{
                $aumento = $salario * 0.1;
                $salario += $aumento;
            }
        }
    }
    return $salario;
?>