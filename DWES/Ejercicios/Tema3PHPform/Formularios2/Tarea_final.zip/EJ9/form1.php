<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>CALCULOS ESTADISTICOS</h1>
    <p>Escribe cuantos valores quieres introducir</p>
    <form action="form2.php" method="post">
        <label>Cantidad: </label>
        <input type="text" name="cantidad">
        <br>
        <input type="submit" value="Mostrar formulario de entrada">
    </form>
    <?php 
        
    ?>
</body>
</html>